package shapes;

import java.util.ArrayList;

public class ShapeContainer {

    //Properties
    public ArrayList<Shape> shapes;

    //Constructor
    public ShapeContainer(){
        this.shapes = new ArrayList<>();
    }

    //Methods
    //This method adds shape to our set
    public void add(Shape shape){
        this.shapes.add(shape);
    }

    //This method returns the totalArea of all the shapes in our set
    public double getArea(){
        double totalArea = 0;
        for (Shape shape : shapes)
        {
            totalArea = shape.getArea() + totalArea;
        }
        return totalArea;
    }

    //toString method
    public String toString(){
        StringBuilder str = new StringBuilder();
        for (int i = 0; i < size(); i++)
        {
            str.append(shapes.get(i).toString()).append("\n");
        }
        return str.toString();
    }

    //Gives the amount of elements in the container
    public int size(){
        return shapes.size();
    }

    //Removes all selected shapes
    public void removeSelected( ){
        for (int i = 0; i < size(); i++){
            assert shapes.get(i) instanceof ISelectable;
            if (((ISelectable) shapes.get(i)).getSelected()){
                shapes.remove(shapes.get(i));
                i = 0;
            }
        }
    }

    //Selects all shapes at given x,y coordinates
    public int selectAllAt(int x, int y){
        int totalShapes = 0;
        for ( int i = 0; i < shapes.size(); i ++){
            assert shapes.get(i) instanceof ISelectable;
            if (((ISelectable) shapes.get(i)).contains(x, y) != null){
                ((ISelectable) shapes.get(i)).setSelected(true);
                totalShapes++;
            }
        }
        return totalShapes;
    }

}
