package shapes;

public interface ILocatable {

    //Methods
    int getX();
    int getY();
    void setLocations(int x, int y);

}
