package shapes;

public class Rectangle extends Shape implements ISelectable {

    //Properties
    int width;
    int height;
    boolean selected;

    //Methods

    //Constructor
    public Rectangle( int width, int height, int centerX, int centerY , boolean selected  ){
        super( centerX, centerY);
        this.width = width;
        this.height = height;
        this.selected = selected;
    }

    //Getters and Setters
    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    //Override methods
    @Override
    public double getArea() {
        return width * height ;
    }

    @Override
    public String toString() {
        return "Rectangle -- Height: " + height + " -- Width: " + width + " -- Area: " + getArea() + " -- Selected: " + getSelected();
    }

    @Override
    public boolean getSelected() {
        return selected;
    }

    @Override
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    @Override
    public Shape contains(int x, int y) {
        if( ( x < super.getX() + width / 2 && x > super.getX() - width / 2 ) && ( y < super.getY() + height / 2 && y > super.getY() / 2 )){
            return this;
        }
        else{
            return null;
        }
    }
}

