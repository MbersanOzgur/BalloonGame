package shapes;

public abstract class Shape implements ILocatable {

    //Properties
    int x;
    int y;

    //Methods

    //Constructor
    public Shape(int x, int y) {
        this.x = x;
        this.y = y;
    }

    //Override methods from ILocatable
    @Override
    public int getX() {
        return x;
    }

    @Override
    public int getY() {
        return y;
    }

    @Override
    public void setLocations(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Abstract methods
    public abstract double getArea();

    public abstract String toString();
}

