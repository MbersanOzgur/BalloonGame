package shapes;

import java.awt.*;

public interface IDrawable
{
    void draw(Graphics g);
}
