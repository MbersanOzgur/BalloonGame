package shapes;

public class Circle extends Shape implements ISelectable
{

    //Properties
    int radius;
    boolean selected;

    //Methods

    //Constructor
    public Circle(int radius, int centerX, int centerY, boolean selected){
        super( centerX , centerY );
        this.radius = radius;
        this.selected = selected;
    }

    //Getter and Setter
    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    //Override methods
    @Override
    public double getArea() {
        return Math.PI * Math.pow(radius , 2);
    }

    @Override
    public String toString(){
        return "Circle -- Radius: " + getRadius() + " -- Area: " + getArea() + " -- Selected: " + getSelected();
    }

    @Override
    public boolean getSelected(){
        return selected;
    }

    @Override
    public void setSelected( boolean selected ){
        this.selected = selected;
    }

    @Override
    public Shape contains(int x, int y) {
        if( radius > Math.sqrt( Math.pow(x - getX(), 2) + Math.pow(y - getY() , 2))){
            return this;
        }
        else{
            return null;
        }
    }
}
