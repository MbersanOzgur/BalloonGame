package shapes;

public class Square extends Rectangle {

    //Properties
    int side;
    int x;
    int y;
    boolean selected;

    //Methods

    //Constructor
    public Square( int side , int x, int y, boolean selected) {
        super( side, side, x, y, selected);
    }

    //Getter and Setter
    public int getSide() {
        return side;
    }

    public void setSide(int side) {
        this.side = side;
    }

    //Override method
    @Override
    public double getArea() {
        return super.getArea();
    }

    @Override
    public String toString() {
        return super.toString() + " -- SQUARE RECTANGLE" ;
    }
}

