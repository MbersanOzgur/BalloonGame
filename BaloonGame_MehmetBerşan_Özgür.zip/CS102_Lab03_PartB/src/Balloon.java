import shapes.Circle;
import shapes.IDrawable;

import java.awt.*;

public class Balloon extends Circle implements IDrawable {
    //properties

    //constructors
    public Balloon(int centerX, int centerY, boolean selected) {
        super(25, centerX, centerY, selected);
    }

    public Balloon(int radius, int centerX, int centerY, boolean selected) {
        super(radius, centerX, centerY, selected);
    }

    //methods
    @Override
    public void draw(Graphics g) {
        g.drawOval(this.getX() - this.getRadius() , this.getY() - this.getRadius() , this.getRadius() * 2, this.getRadius() * 2);
    }

    public void grow(){
        this.setRadius( getRadius() + 1 );

    }
}

