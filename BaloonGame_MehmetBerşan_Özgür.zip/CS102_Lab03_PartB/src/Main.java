import shapes.Circle;
import shapes.ShapeContainer;

import javax.swing.*;
import java.awt.*;

public class Main
{
    public static void main(String[] args)
    {
        JFrame frame = new JFrame();
        BalloonsGamePanel gamePanel = new BalloonsGamePanel();
        frame.add(gamePanel);
        gamePanel.createRandomBalloon(25);
        gamePanel.setBackground(Color.YELLOW);
        frame.setPreferredSize(new Dimension(1024, 768));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack(); //questionable
        frame.setVisible(true);
    }
}

