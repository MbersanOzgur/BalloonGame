import shapes.IDrawable;
import shapes.ShapeContainer;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.Duration;
import java.time.Instant;

class BalloonsGamePanel extends JPanel
{
    //properties
    public ShapeContainer balloons;
    public Timer timer;
    public int elapsedTime;
    public int point;
    public JLabel label;
    public JLabel label2;
    //constructors
    public BalloonsGamePanel(){
        balloons = new ShapeContainer();
        elapsedTime = 0;
        point = 0;
        timer = new Timer(250 , new BalloonsGamePanel.BalloonListener() );
        this.timer.start();
        BurstListener burstListener = new BurstListener();
        this.addMouseListener( burstListener );
        label = new JLabel("Timer : 0");
        label2 = new JLabel("Points : 0");
        add(label);
        add(label2);
    }

    //methods
    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        for (int i = 0; i < balloons.size(); i++){
            ((IDrawable) balloons.shapes.get(i)).draw(g);
            //(((Balloon) balloons.shapes.get(i))).grow();
        }
    }

    public void createRandomBalloon( int numberOfCircle ){
        int x;
        int y;
        Balloon randomCircle;
        for(int i = 0; i < numberOfCircle; i ++ ){
            x = (int)(Math.random() * 1024);
            y = (int)(Math.random() * 768);
            randomCircle = new Balloon(25 , x , y , false);
            balloons.shapes.add(randomCircle);
        }
    }

    public class BurstListener extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent e) {
            balloons.selectAllAt(e.getX(), e.getY());
            balloons.removeSelected();
            point ++;
            label2.setText("Point : " + point);
        }
    }

    public class BalloonListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            for(int i = 0; i < balloons.shapes.size() - 1; i ++){
                (((Balloon) balloons.shapes.get(i))).grow();
            }
            repaint();
            elapsedTime = elapsedTime + 1;
            label.setText("Timer : " + elapsedTime);
        }
    }

}

